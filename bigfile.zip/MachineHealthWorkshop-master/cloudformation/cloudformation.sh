aws cloudformation deploy --capabilities CAPABILITY_IAM --template-file template.yml --stack mustafa1
